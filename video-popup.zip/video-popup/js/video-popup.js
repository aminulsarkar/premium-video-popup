/**
 * Premium Video Popup
 * 
 * A lightweight video popup component with:
 * - Delayed appearance
 * - Session-based display control
 * - Autoplay fallback
 * - Sound/unmute control
 * - Smooth entrance/exit animation
 * - Navigation cleanup
 * - Page visibility cleanup
 *
 * @author Aminul Sarkar
 * @link https://aminulsarkar.com
 */

document.addEventListener("DOMContentLoaded", function () {

  const popup = document.getElementById("video-popup");
  const video = document.getElementById("popup-video");
  const unmuteBtn = document.getElementById("unmute-btn");
  const closeBtn = document.getElementById("close-popup");

  // Stop if required elements are missing.
  if (!popup || !video) {
    return;
  }

  const STORAGE_KEY = "videoPopupShown";
  const SHOW_DELAY = 3000;
  const ANIMATION_DURATION = 600;

  /**
   * Check whether the popup has already
   * been displayed during this session.
   */
  const alreadyShown =
    sessionStorage.getItem(STORAGE_KEY) === "true";

  if (alreadyShown) {
    popup.style.display = "none";
    popup.style.opacity = "0";
    popup.style.transform = "translateX(100px)";

    video.pause();
    video.currentTime = 0;

    return;
  }

  /**
   * Stop and reset the video.
   */
  function resetVideo() {
    try {
      video.pause();
      video.currentTime = 0;
      video.muted = true;
    } catch (error) {
      // Ignore video reset errors.
    }
  }

  /**
   * Show the popup with animation.
   */
  function showPopup() {

    popup.style.display = "block";

    // Allow the browser to apply display:block
    // before starting the transition.
    requestAnimationFrame(function () {
      popup.style.opacity = "1";
      popup.style.transform = "translateX(0)";
    });

    // Try autoplay with sound first.
    video.muted = false;

    const playPromise = video.play();

    if (playPromise !== undefined) {

      playPromise.catch(function () {

        // Browser blocked autoplay with sound.
        video.muted = true;

        video.play().catch(function () {
          // Autoplay may still be blocked.
        });

        if (unmuteBtn) {
          unmuteBtn.style.display = "block";
        }
      });
    }

    // Remember that the popup was displayed.
    sessionStorage.setItem(STORAGE_KEY, "true");
  }

  /**
   * Hide the popup with animation.
   */
  function hidePopup() {

    popup.style.opacity = "0";
    popup.style.transform = "translateX(100px)";

    setTimeout(function () {

      popup.style.display = "none";

      resetVideo();

    }, ANIMATION_DURATION);
  }

  /**
   * Show popup after page load.
   */
  window.addEventListener("load", function () {

    setTimeout(function () {
      showPopup();
    }, SHOW_DELAY);

  });

  /**
   * Unmute video.
   */
  if (unmuteBtn) {

    unmuteBtn.addEventListener("click", function () {

      video.muted = false;

      video.play().catch(function () {
        // Ignore playback errors.
      });

      unmuteBtn.style.display = "none";

    }, { once: true });

  }

  /**
   * Close popup.
   */
  if (closeBtn) {

    closeBtn.addEventListener("click", function () {
      hidePopup();
    });

  }

  /**
   * Stop video when navigating internally.
   *
   * This prevents the video from continuing to play
   * while the browser is changing pages.
   */
  document.addEventListener("click", function (event) {

    const link = event.target.closest("a");

    if (!link) {
      return;
    }

    const href = link.getAttribute("href");

    if (!href) {
      return;
    }

    // Ignore anchors and special links.
    if (
      href.startsWith("#") ||
      href.startsWith("mailto:") ||
      href.startsWith("tel:") ||
      href.startsWith("javascript:")
    ) {
      return;
    }

    const target = link.getAttribute("target");

    if (target && target !== "_self") {
      return;
    }

    try {

      const url = new URL(href, window.location.href);

      // Only handle same-origin navigation.
      if (url.origin !== window.location.origin) {
        return;
      }

    } catch (error) {
      return;
    }

    resetVideo();

  }, true);

  /**
   * Stop video when the page is being unloaded.
   */
  window.addEventListener("pagehide", function () {
    resetVideo();
  });

  /**
   * Stop video when the page becomes hidden.
   */
  document.addEventListener("visibilitychange", function () {

    if (document.hidden) {
      resetVideo();
    }

  });

});